-- Создание схемы базы
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  balance DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS case_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_id INT NOT NULL,
  name VARCHAR(150) NOT NULL,
  rarity VARCHAR(50) NOT NULL,
  float_min DECIMAL(5,4) DEFAULT 0,
  float_max DECIMAL(5,4) DEFAULT 1,
  chance DECIMAL(5,4) NOT NULL, -- probability weight
  image VARCHAR(255) DEFAULT NULL,
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS drops (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  case_id INT NOT NULL,
  item_id INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (case_id) REFERENCES cases(id),
  FOREIGN KEY (item_id) REFERENCES case_items(id)
);

-- Пример данных
INSERT INTO cases (name, price) VALUES ('Starter Case', 1.00);

INSERT INTO case_items (case_id, name, rarity, chance, image) VALUES
(1, 'Common Knife Skin', 'common', 0.7000, 'assets/items/common-knife.png'),
(1, 'Rare Rifle Skin', 'rare', 0.2000, 'assets/items/rare-rifle.png'),
(1, 'Epic Pistol Skin', 'epic', 0.0900, 'assets/items/epic-pistol.png'),
(1, 'Legendary Knife', 'legendary', 0.0100, 'assets/items/legendary-knife.png');
