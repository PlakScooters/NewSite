<?php
// usage: php create_admin.php username password
if($argc < 3) {
    echo "Usage: php create_admin.php username password\n";
    exit(1);
}
$username = $argv[1];
$password = $argv[2];

$config = require __DIR__ . '/../config.php';
$db = $config['db'];
$pdo = new PDO("mysql:host={$db['host']};dbname={$db['dbname']};charset={$db['charset']}", $db['user'], $db['pass']);

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO users (username, password_hash, balance) VALUES (?, ?, ?)');
try {
    $stmt->execute([$username, $hash, 0.00]);
    $id = $pdo->lastInsertId();
    $stmt = $pdo->prepare('UPDATE users SET is_admin = 1 WHERE id = ?');
    $stmt->execute([$id]);
    echo "Admin user created with id: $id\n";
} catch(Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
