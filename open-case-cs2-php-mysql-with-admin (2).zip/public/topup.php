<?php
session_start();
if(!isset($_SESSION['user_id'])) header('Location: login.php');
$amt = floatval($_POST['amount']);
if($amt <= 0) { header('Location: dashboard.php'); exit; }
$c = require __DIR__ . '/../config.php';
$d = $c['db'];
$pdo = new PDO("mysql:host={$d['host']};dbname={$d['dbname']};charset={$d['charset']}", $d['user'], $d['pass']);
$stmt = $pdo->prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
$stmt->execute([$amt, $_SESSION['user_id']]);
header('Location: dashboard.php');
