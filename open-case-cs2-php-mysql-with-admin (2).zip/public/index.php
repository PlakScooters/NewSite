<?php
session_start();
$config = require __DIR__ . '/../config.php';
function db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    $c = require __DIR__ . '/../config.php';
    $d = $c['db'];
    $dsn = "mysql:host={$d['host']};dbname={$d['dbname']};charset={$d['charset']}";
    $pdo = new PDO($dsn, $d['user'], $d['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    return $pdo;
}

$logged = isset($_SESSION['user_id']);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Open Case CS2 - Demo</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <header>
    <h1>Open Case CS2 — Demo</h1>
    <?php if($logged): ?>
      <a href="dashboard.php">Кабинет</a> |
      <a href="logout.php">Выйти</a>
    <?php else: ?>
      <a href="login.php">Войти</a> |
      <a href="register.php">Регистрация</a>
    <?php endif; ?>
  </header>

  <main>
    <h2>Добро пожаловать</h2>
    <p>Демо-версия сайта открытия кейсов. Войдите или зарегистрируйтесь, чтобы начать.</p>
  </main>
</body>
</html>
