<?php
session_start();
if(!isset($_SESSION['user_id'])) header('Location: login.php');
$c = require __DIR__ . '/../config.php';
$d = $c['db'];
$pdo = new PDO("mysql:host={$d['host']};dbname={$d['dbname']};charset={$d['charset']}", $d['user'], $d['pass']);

// user
$stmt = $pdo->prepare('SELECT id, username, balance FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// cases
$cases = $pdo->query('SELECT * FROM cases')->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Кабинет</title>
<link rel="stylesheet" href="assets/css/style.css">
</head><body>
<header>
  <a href="index.php">На главную</a> | <a href="logout.php">Выйти</a>
</header>
<main>
  <h2>Привет, <?=htmlspecialchars($user['username'])?></h2>
  <p>Баланс: <strong id="balance"><?=number_format($user['balance'],2)?></strong> ₽</p>

  <h3>Кейсы</h3>
  <div class="cases">
    <?php foreach($cases as $c): ?>
      <div class="case-card">
        <h4><?=htmlspecialchars($c['name'])?></h4>
        <p>Цена: <?=number_format($c['price'],2)?> ₽</p>
        <a class="open-btn" href="open_case.php?case_id=<?=intval($c['id'])?>">Открыть</a>
      </div>
    <?php endforeach; ?>
  </div>

  <h3>Пополнение (симуляция)</h3>
  <form action="topup.php" method="post">
    <input name="amount" type="number" step="0.01" min="0.01" value="1.00" required>
    <button>Пополнить</button>
  </form>
</main>
</body></html>
