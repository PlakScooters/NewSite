// Simple client-side animation + request to server to perform the opening
document.getElementById('openBtn').addEventListener('click', async () => {
  const btn = document.getElementById('openBtn');
  btn.disabled = true;
  btn.textContent = 'Открытие...';
  // call backend to perform transaction & random selection
  const resp = await fetch('api/open_case.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({case_id: caseId})
  });
  const data = await resp.json();
  if(!data.success){
    alert(data.error || 'Ошибка');
    btn.disabled = false;
    btn.textContent = 'Открыть за ' + price + ' ₽';
    return;
  }
  // animate "wheel"
  const wheel = document.getElementById('wheel');
  wheel.textContent = '...';
  let i = 0;
  const interval = setInterval(()=>{
    wheel.textContent = items[i % items.length].name + ' (' + items[i % items.length].rarity + ')';
    i++;
  }, 80);
  setTimeout(()=>{
    clearInterval(interval);
    wheel.textContent = data.item.name + ' — ' + data.item.rarity;
    const div = document.createElement('div');
    div.className = 'result';
    div.innerHTML = '<strong>Выпало:</strong> ' + data.item.name + ' (' + data.item.rarity + ')';
    document.getElementById('case-area').appendChild(div);
    btn.disabled = false;
    btn.textContent = 'Открыть за ' + price + ' ₽';
    // update balance on page if present
    const balEl = document.getElementById('balance');
    if(balEl && data.balance !== undefined) balEl.textContent = parseFloat(data.balance).toFixed(2);
  }, 3000);
});
