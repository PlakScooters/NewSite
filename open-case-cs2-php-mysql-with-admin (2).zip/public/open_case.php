<?php
session_start();
if(!isset($_SESSION['user_id'])) header('Location: login.php');
$c = require __DIR__ . '/../config.php';
$d = $c['db'];
$pdo = new PDO("mysql:host={$d['host']};dbname={$d['dbname']};charset={$d['charset']}", $d['user'], $d['pass']);

$case_id = intval($_GET['case_id'] ?? 0);
if(!$case_id) { header('Location: dashboard.php'); exit; }

// load case
$stmt = $pdo->prepare('SELECT * FROM cases WHERE id = ?');
$stmt->execute([$case_id]);
$case = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$case) { header('Location: dashboard.php'); exit; }

// items
$stmt = $pdo->prepare('SELECT * FROM case_items WHERE case_id = ?');
$stmt->execute([$case_id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ensure user has enough balance
$stmt = $pdo->prepare('SELECT balance FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$u = $stmt->fetch(PDO::FETCH_ASSOC);
if($u['balance'] < $case['price']) {
    $error = 'Недостаточно средств';
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Открыть кейс</title>
<link rel="stylesheet" href="assets/css/style.css">
</head><body>
<header><a href="dashboard.php">Назад</a></header>
<main>
  <h2>Открытие: <?=htmlspecialchars($case['name'])?></h2>
  <?php if(!empty($error)): ?>
    <p style="color:red"><?=htmlspecialchars($error)?></p>
  <?php else: ?>
    <div id="case-area">
      <div id="wheel"></div>
      <button id="openBtn">Открыть за <?=number_format($case['price'],2)?> ₽</button>
    </div>
    <script>
      const items = <?=json_encode($items)?>;
      const caseId = <?=json_encode($case_id)?>;
      const price = <?=json_encode($case['price'])?>;
    </script>
    <script src="assets/js/open-case.js"></script>
  <?php endif; ?>
</main>
</body></html>
