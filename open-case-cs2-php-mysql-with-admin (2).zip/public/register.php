<?php
session_start();
if(isset($_SESSION['user_id'])) header('Location: dashboard.php');
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $c = require __DIR__ . '/../config.php';
    $d = $c['db'];
    $pdo = new PDO("mysql:host={$d['host']};dbname={$d['dbname']};charset={$d['charset']}", $d['user'], $d['pass']);
    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, balance) VALUES (?, ?, ?)');
    $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
    try {
        $stmt->execute([$_POST['username'], $hash, 5.00]); // стартовый баланс 5
        $_SESSION['user_id'] = $pdo->lastInsertId();
        header('Location: dashboard.php');
        exit;
    } catch(Exception $e) {
        $error = 'Ошибка: возможно пользователь уже существует';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Регистрация</title></head><body>
<h2>Регистрация</h2>
<?php if(!empty($error)) echo '<p style="color:red">'.htmlspecialchars($error).'</p>'; ?>
<form method="post">
  <label>Имя: <input name="username" required></label><br>
  <label>Пароль: <input name="password" type="password" required></label><br>
  <button>Зарегистрироваться</button>
</form>
</body></html>
