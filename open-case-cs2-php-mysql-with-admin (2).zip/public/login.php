<?php
session_start();
if(isset($_SESSION['user_id'])) header('Location: dashboard.php');
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $c = require __DIR__ . '/../config.php';
    $d = $c['db'];
    $pdo = new PDO("mysql:host={$d['host']};dbname={$d['dbname']};charset={$d['charset']}", $d['user'], $d['pass']);
    $stmt = $pdo->prepare('SELECT id, password_hash FROM users WHERE username = ?');
    $stmt->execute([$_POST['username']]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if($u && password_verify($_POST['password'], $u['password_hash'])){
        $_SESSION['user_id'] = $u['id'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Неверные учетные данные';
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Вход</title></head><body>
<h2>Вход</h2>
<?php if(!empty($error)) echo '<p style="color:red">'.htmlspecialchars($error).'</p>'; ?>
<form method="post">
  <label>Имя: <input name="username" required></label><br>
  <label>Пароль: <input name="password" type="password" required></label><br>
  <button>Войти</button>
</form>
</body></html>
