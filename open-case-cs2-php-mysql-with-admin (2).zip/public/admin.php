<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php'); exit;
}
$config = require __DIR__ . '/../config.php';
$db = $config['db'];
$pdo = new PDO("mysql:host={$db['host']};dbname={$db['dbname']};charset={$db['charset']}", $db['user'], $db['pass']);
$stmt = $pdo->prepare('SELECT is_admin FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$is_admin = $stmt->fetchColumn();
if(!$is_admin) { echo 'Доступ запрещен'; exit; }

// handle add case
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if($_POST['action'] === 'add_case') {
        $name = $_POST['name'] ?? '';
        $price = floatval($_POST['price'] ?? 0);
        $stmt = $pdo->prepare('INSERT INTO cases (name, price) VALUES (?, ?)');
        $stmt->execute([$name, $price]);
        $msg = 'Кейс добавлен';
    } elseif($_POST['action'] === 'add_item') {
        $case_id = intval($_POST['case_id'] ?? 0);
        $iname = $_POST['iname'] ?? '';
        $rarity = $_POST['rarity'] ?? '';
        $chance = floatval($_POST['chance'] ?? 0);
        $img = $_POST['image'] ?? '';
        $stmt = $pdo->prepare('INSERT INTO case_items (case_id, name, rarity, chance, image) VALUES (?,?,?,?,?)');
        $stmt->execute([$case_id, $iname, $rarity, $chance, $img]);
        $msg = 'Предмет добавлен';
    }
}

// load cases for selection
$cases = $pdo->query('SELECT id, name FROM cases')->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Админ-панель</title></head><body>
<h2>Админ-панель</h2>
<p><a href="dashboard.php">Назад</a></p>
<?php if(!empty($msg)) echo '<p style="color:green">'.htmlspecialchars($msg).'</p>'; ?>

<h3>Добавить кейс</h3>
<form method="post">
  <input type="hidden" name="action" value="add_case">
  <label>Название: <input name="name" required></label><br>
  <label>Цена: <input name="price" required type="number" step="0.01" value="1.00"></label><br>
  <button>Добавить кейс</button>
</form>

<h3>Добавить предмет в кейс</h3>
<form method="post">
  <input type="hidden" name="action" value="add_item">
  <label>Кейс:
    <select name="case_id">
      <?php foreach($cases as $c): ?>
        <option value="<?=intval($c['id'])?>"><?=htmlspecialchars($c['name'])?></option>
      <?php endforeach; ?>
    </select>
  </label><br>
  <label>Название предмета: <input name="iname" required></label><br>
  <label>Редкость: <input name="rarity" value="common" required></label><br>
  <label>Шанс (например 0.75): <input name="chance" type="number" step="0.0001" value="0.1000" required></label><br>
  <label>Путь к изображению: <input name="image"></label><br>
  <button>Добавить предмет</button>
</form>

</body></html>
