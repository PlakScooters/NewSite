<?php
// POST JSON { case_id }
session_start();
header('Content-Type: application/json');
if(!isset($_SESSION['user_id'])) {
    echo json_encode(['success'=>false,'error'=>'Not logged in']); exit;
}
$input = json_decode(file_get_contents('php://input'), true);
$case_id = intval($input['case_id'] ?? 0);
if(!$case_id) { echo json_encode(['success'=>false,'error'=>'Invalid case']); exit; }

$c = require __DIR__ . '/../../config.php';
$d = $c['db'];
$pdo = new PDO("mysql:host={$d['host']};dbname={$d['dbname']};charset={$d['charset']}", $d['user'], $d['pass']);
$pdo->beginTransaction();
try {
    // get case
    $stmt = $pdo->prepare('SELECT * FROM cases WHERE id = ? FOR UPDATE');
    $stmt->execute([$case_id]);
    $case = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$case) throw new Exception('Case not found');

    // check balance
    $stmt = $pdo->prepare('SELECT id, balance FROM users WHERE id = ? FOR UPDATE');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$user) throw new Exception('User not found');
    if($user['balance'] < $case['price']) throw new Exception('Недостаточно средств');

    // get items and total weight
    $stmt = $pdo->prepare('SELECT * FROM case_items WHERE case_id = ?');
    $stmt->execute([$case_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total = 0;
    foreach($items as $it) $total += floatval($it['chance']);

    // random pick
    $r = mt_rand(1, 1000000) / 1000000 * $total;
    $acc = 0;
    $picked = null;
    foreach($items as $it){
        $acc += floatval($it['chance']);
        if($r <= $acc){ $picked = $it; break; }
    }
    if(!$picked) $picked = end($items);

    // deduct price
    $stmt = $pdo->prepare('UPDATE users SET balance = balance - ? WHERE id = ?');
    $stmt->execute([$case['price'], $_SESSION['user_id']]);

    // insert drop
    $stmt = $pdo->prepare('INSERT INTO drops (user_id, case_id, item_id, price) VALUES (?, ?, ?, ?)');
    $stmt->execute([$_SESSION['user_id'], $case_id, $picked['id'], $case['price']]);

    // get new balance
    $stmt = $pdo->prepare('SELECT balance FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $newBal = $stmt->fetchColumn();

    $pdo->commit();
    echo json_encode(['success'=>true,'item'=>$picked,'balance'=>floatval($newBal)]);
} catch(Exception $e){
    $pdo->rollBack();
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
